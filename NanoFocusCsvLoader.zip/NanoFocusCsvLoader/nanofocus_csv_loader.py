import os
import re
import tempfile

import numpy as np

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox, QInputDialog
from qgis.core import QgsProject, QgsRasterLayer

from osgeo import gdal


def _parse_header(path):
    meta = {}
    n_header = 0
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            if not line.startswith("#"):
                break
            n_header += 1
            m = re.match(r"#\s*([^:]+)\s*:\s*(.*)\s*$", line)
            if m:
                key = m.group(1).strip()
                val = m.group(2).strip()
                meta[key] = val
    return meta, n_header


def _load_points(path, skiprows):
    data = np.loadtxt(path, delimiter=",", skiprows=skiprows)
    if data.ndim == 1:
        data = data.reshape(1, -1)
    if data.shape[1] < 5:
        raise ValueError(f"Expected 5 columns (X,Y,Z,Intensity,Mask) but got {data.shape[1]}")
    x = data[:, 0]
    y = data[:, 1]
    z = data[:, 2]
    intensity = data[:, 3]
    mask = data[:, 4]
    return x, y, z, intensity, mask


def _points_to_grid(x, y, v, nx, ny, dx, dy):
    xmin = np.min(x)
    ymin = np.min(y)

    ix = np.rint((x - xmin) / dx).astype(np.int64)
    iy = np.rint((y - ymin) / dy).astype(np.int64)

    grid = np.full((ny, nx), np.nan, dtype=np.float32)

    ok = (ix >= 0) & (ix < nx) & (iy >= 0) & (iy < ny)
    ix = ix[ok]
    iy = iy[ok]
    v = v[ok].astype(np.float32)

    grid[iy, ix] = v
    return grid, xmin, ymin


def _write_geotiff(out_path, grid, xmin, ymin, dx, dy, nodata=np.nan):
    ny, nx = grid.shape

    grid_flip = np.flipud(grid)

    ymax = ymin + dy * (ny - 1)
    gt = (xmin, dx, 0.0, ymax, 0.0, -dy)

    driver = gdal.GetDriverByName("GTiff")
    ds = driver.Create(out_path, nx, ny, 1, gdal.GDT_Float32, options=["COMPRESS=LZW"])
    ds.SetGeoTransform(gt)

    band = ds.GetRasterBand(1)
    # GDAL doesn't truly support NaN nodata for all workflows; still commonly used.
    # For Mask, we use -9999 as nodata instead (see call site).
    band.SetNoDataValue(nodata)
    band.WriteArray(grid_flip)
    band.FlushCache()

    ds.FlushCache()
    ds = None


class NanoFocusCsvLoaderPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def tr(self, message):
        return QCoreApplication.translate("NanoFocusCsvLoader", message)

    def initGui(self):
        self.action = QAction(self.tr("Load NanoFocus CSV…"), self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu(self.tr("&NanoFocus CSV Loader"), self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu(self.tr("&NanoFocus CSV Loader"), self.action)
            self.action = None

    def run(self):
        path, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(),
            self.tr("Select NanoFocus CSV"),
            "",
            self.tr("CSV Files (*.csv *.txt);;All Files (*)")
        )
        if not path:
            return

        # --- choose band
        band_options = ["Z", "Intensity", "Mask"]
        band_name, ok = QInputDialog.getItem(
            self.iface.mainWindow(),
            self.tr("Select band"),
            self.tr("Load which band?"),
            band_options,
            0,
            False
        )
        if not ok or not band_name:
            return

        try:
            meta, n_header = _parse_header(path)

            nx = int(meta.get("PointsX"))
            ny = int(meta.get("PointsY"))
            dx = float(meta.get("DeltaX"))
            dy = float(meta.get("DeltaY"))
            unit = float(meta.get("Unit", "1"))

            x, y, z, intensity, mask = _load_points(path, n_header)

            # Pick requested band
            if band_name == "Z":
                v = z * unit  # scale Z by Unit
                # If you want to respect mask: uncomment next line
                # v = np.where(mask > 0, v, np.nan)
                nodata = np.nan
            elif band_name == "Intensity":
                v = intensity
                # Optional mask application:
                # v = np.where(mask > 0, v, np.nan)
                nodata = np.nan
            else:  # "Mask"
                v = mask
                # For mask, a numeric nodata is often cleaner than NaN
                nodata = -9999.0
                v = np.where(np.isfinite(v), v, nodata)

            grid, xmin, ymin = _points_to_grid(x, y, v, nx, ny, dx, dy)

            base = os.path.splitext(os.path.basename(path))[0]
            out_path = os.path.join(tempfile.gettempdir(), f"{base}_{band_name}.tif")

            # Ensure nodata is present in grid for Mask if desired
            if band_name == "Mask":
                grid = np.where(np.isnan(grid), nodata, grid)

            _write_geotiff(out_path, grid, xmin, ymin, dx, dy, nodata=nodata)

            layer_name = f"{base} ({band_name})"
            rlayer = QgsRasterLayer(out_path, layer_name)
            if not rlayer.isValid():
                raise RuntimeError("Created raster layer is invalid. GeoTIFF write may have failed.")

            QgsProject.instance().addMapLayer(rlayer)

            QMessageBox.information(
                self.iface.mainWindow(),
                self.tr("NanoFocus CSV Loader"),
                self.tr(f"Loaded raster layer:\n{layer_name}\n\nGeoTIFF saved to:\n{out_path}")
            )

        except Exception as e:
            QMessageBox.critical(
                self.iface.mainWindow(),
                self.tr("NanoFocus CSV Loader - Error"),
                str(e)
            )