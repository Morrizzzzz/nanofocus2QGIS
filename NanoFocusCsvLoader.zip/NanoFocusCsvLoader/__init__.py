def classFactory(iface):
    from .nanofocus_csv_loader import NanoFocusCsvLoaderPlugin
    return NanoFocusCsvLoaderPlugin(iface)